package com.ennvee.ProjectManagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseManagement {
    private static String connectionUrl = "jdbc:sqlserver://ennvee5:1433;" +
			"databaseName=projectmangementtools";
    private static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";   
    private static String username="sa";
    private static String password="root";
    private static Connection con;
    public static Connection getConnection() {
        try {
            Class.forName(driverName);
            try {
                con = DriverManager.getConnection(connectionUrl,username,password);
            } catch (SQLException ex) {
               
                System.out.println("Failed to create the database connection."); 
            }
        } catch (ClassNotFoundException ex) {
            // log an exception. for example:
            System.out.println("Driver not found."); 
        }
        return con;
    }
}