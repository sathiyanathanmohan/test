package com.ennvee.ProjectManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Sample {

//	public static void main(String[] args) throws SQLException {
//		Connection con=DatabaseManagement.getConnection();
//		
//		Statement st=con.createStatement();
//		st.executeUpdate("insert into sample values('sathiya',24)");
////		PreparedStatement pre=con.prepareStatement("insert into sample values (?,?)");
////		
////		  pre.setString(2, "sathiya");
////		pre.setInt(3, 24);
////         pre.executeUpdate();
////         con.close();
//	}

}
