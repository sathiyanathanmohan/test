
var user;
$(document).ready(function(){
$( window ).load(function() {
	 
	
	var user2= checkCookie(decodeURIComponent(document.cookie));
	var designation=checkCookie3(decodeURIComponent(document.cookie));
	//alert(designation);
		if(user2!=null){
			if(designation!='project_manager'&&designation!='admin')
				{
				 location.href='timesheetentry.html';
				}
			else{	
	   $('#welcomeuser').append("Welcome "+user2+" !") ;
	var url = "rest/webservices/getallproject";
	var k=1,c,d,e;
//alert(url);
	$.ajax({
	        type: "GET",
	        dataType:"json",
	        url: url,
	        success: function(data) {
	            console.log("response:" + data);
					
					var object=data.object;
					
	            for ( var i in object) {
                    c=object[i].project_code;
                    d=object[i].project_name;
                    e=object[i].id;
               
            	$("#c1")
	            	.append('<tr align="center"><td>'+ k +'</td><td  >'+object[i].project_code.toUpperCase()+'</td><td  >'+object[i].project_name.toUpperCase()+'</td><td>'+object[i].start_date+'</td><td>'+object[i].end_date+'</td>'
	            			+'<td ><button  id="alloc" onclick=location.href="Projectallocation.html?a='+e+'";>Allocate</button><td><button id="dashedit" onclick=location.href="projectedit.jsp?a='+e+'";>Edit</button></tr>');	     
            	 k=k+1;	
                 
                 }
	            $('#example').DataTable();
	           
	        
	        },
				error : function(msg) {
					console.log("User Favorites Details not found", msg);
				}
			});
	    
			}
	    
	    
	    }else{
	    	  location.href='index.html';
	    }
	    
});

});

 
